

/***************************** Include Files *******************************/
#include "DNN_Digit_Recog_Sig8.h"

/************************** Function Definitions ***************************/
